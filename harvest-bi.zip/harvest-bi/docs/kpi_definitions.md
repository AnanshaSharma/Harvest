# KPI definitions (one definition, used by SQL, DAX and the narrative)

| KPI | Definition | SQL (`vw_store_week_kpi`) | DAX measure |
|---|---|---|---|
| Net sales | Sum of sales after discount | `net_sales` | `[Net Sales]` |
| Gross margin % | (Net sales − COGS) ÷ net sales | `gross_margin_pct` | `[Gross Margin %]` |
| Net sales WoW % | This week ÷ prior week − 1; blank when there is no prior week | `net_sales_wow_pct` (`LAG`) | `[Net Sales WoW %]` |
| Waste % of COGS | Cost of wasted units ÷ COGS | `waste_pct_of_cogs` | `[Waste % of COGS]` |
| Stockout rate | Store-product-days ending with zero stock ÷ store-product-days tracked | `stockout_rate` | `[Stockout Rate]` |
| Supplier on-time % | PO lines received on/before the promised date ÷ PO lines received, **in the week of receipt** | `supplier_on_time_rate` | `[Supplier On-Time %]` |
| Fill rate | Units received ÷ units ordered | `fill_rate` | `[Fill Rate]` |

Rules that apply everywhere
- Ratios are always re-derived from summed numerators and denominators, never averaged. The SQL view exposes the
  components so company/region figures can be rebuilt correctly (`kpi.py` does exactly this).
- Weeks start on Monday (`dim_date.week_start`).
- A PO line counts as late if `received_date_key > promised_date_key`; received-short lines still count as on time
  if they arrived on time (the shortage shows up in fill rate instead).
- Stockout rate counts end-of-day on-hand = 0; intraday stockouts are not visible in daily snapshots.

Default targets (placeholders in `measures.dax`): margin 25%, waste 4% of COGS, stockout 8%, on-time 90%.
