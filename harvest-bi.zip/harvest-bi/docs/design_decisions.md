# Design decisions

**1. Star schema, one grain per fact.** Sales, inventory and waste are `date x store x product`; procurement is
one row per PO line. Different processes, different grains, never mixed in one table. Conformed `Date`, `Store`,
`Product` dimensions let one slicer drive every page.

**2. Staging, then an idempotent MERGE.** The loader truncates and reloads `stg_*`, then upserts into the warehouse.
Re-running the same load changes nothing (tested), and a changed source row updates in place instead of duplicating.
Trade-off: MERGE on SQL Server has known edge-case bugs under concurrency; this pipeline is a single writer in one
transaction, which avoids them. For very large facts, partition-level loads would replace full-table MERGE.

**3. Validate before and after the MERGE.** Duplicate grain in staging is a hard stop (MERGE would fail or pick an
arbitrary row). After the MERGE: staging-vs-warehouse totals for every measure, orphan keys on every foreign key, and
business rules (no negative stock, received ≥ ordered date, etc.). Failing pipelines don't publish numbers.

**4. KPIs live in SQL, not only in DAX.** The view is the contract for the narrative, tests and any other consumer;
DAX measures mirror it (see `kpi_definitions.md`). The cost is two implementations of each ratio; the mitigation is a
single definitions table and a test that checks view ratios against their components.

**5. Components next to ratios.** The view exposes numerators and denominators so roll-ups are correct.
Averaging store-level percentages is the most common way a dashboard shows a wrong company number.

**6. One schema spec generates the SQL.** `schema.py` → DDL + MERGE for SQL Server, Snowflake and SQLite. Three dialects
can't drift apart. Trade-off: generated files are less hand-tuned (no indexing/clustering/partitioning choices);
add those in a separate script per platform.

**7. Narrative from governed numbers only.** The LLM receives the KPI summary JSON and is told to use only those
figures; it never queries data. If the API is unavailable, errors, or returns nothing, a deterministic template is used,
so the weekly note is never missing. Trade-off: the model can still phrase a number loosely; a production version would
add an automated check that every number in the output appears in the input.

**8. Security in the model, via a mapping table.** Roles filter only `Store`; relationships propagate. Default-deny for
unknown users. See `rls_guide.md` for the test plan.

**9. Synthetic data is simulated, not random.** Stock, sales, receipts, waste and POs are generated together so the
facts reconcile, and one supplier degrades in the final three weeks so the KPIs have a real signal to detect.

**Known limitations**
- Daily inventory snapshots hide intraday stockouts. No promotions, price changes, returns or transfers.
- Single currency, no store-level targets. No incremental loading by watermark (full reload each run).
- SQL Server / Snowflake paths are generated and reviewed but not exercised by the test suite (SQLite is).
