# Row-level security

## Pattern
One mapping table (`security_user_access`, loaded as `UserAccess`) maps each user's login (UPN) to a role and a
scope. Roles filter **`Store` only**; relationships carry the filter to every fact table, so one rule secures
everything. Adding a user = adding a row, not editing the model.

| Persona type | Rows in `UserAccess` | Sees |
|---|---|---|
| Executive | `role = Executive`, no region/store | All 12 stores |
| Regional manager | `role = Regional`, `region = North` | Stores in that region |
| Store manager | `role = Store`, `store_key = n` | One store |

## Roles (Modeling > Manage roles)

**Executive** – no table filters (included so executives are an explicit, auditable role).

**Regional**
```dax
// table: Store
[region] = LOOKUPVALUE ( UserAccess[region], UserAccess[email], USERPRINCIPALNAME () )
```

**Store**
```dax
// table: Store
[store_key] = LOOKUPVALUE ( UserAccess[store_key], UserAccess[email], USERPRINCIPALNAME () )
```

**On `UserAccess` in every role** (so people can't read each other's rows, while `LOOKUPVALUE` still works):
```dax
[email] = USERPRINCIPALNAME ()
```
> Do **not** use `FALSE()` on `UserAccess`: `LOOKUPVALUE` is evaluated under RLS, so a blanket deny makes the
> role return nothing for everyone.

A user with no row in `UserAccess` gets `BLANK` from `LOOKUPVALUE`, which matches no store, so the default is
**deny**, not allow. Don't assign people to more than one role in the service (roles are additive).

## Proving it by test
1. `python tools/rls_expected.py --db harvest.db` regenerates `docs/rls_expected_values.csv`: for every persona,
   the number of stores and total net sales / units they *should* see, computed from the warehouse, independent
   of Power BI.
2. In Power BI Desktop: **Modeling > View as**, tick the role, and under *Other user* enter the persona's email.
3. On a card/table add `[Stores Visible]`, `[Net Sales]`, `[Units Sold]`, `[Current User]`.
4. Tick every row of the checklist below. Any mismatch is a failed test.

| # | Test | Pass condition |
|---|---|---|
| 1 | View as Executive (`exec@harvest.example`) | 12 stores; net sales equals the Executive row |
| 2 | View as Regional + `north.manager@...` | 4 stores, all North; net sales equals that row |
| 3 | Same for `south.` and `west.` managers | Values match; the three regional totals sum to the Executive total |
| 4 | View as Store + `store1@...` | 1 store; net sales equals that row |
| 5 | Sum all 12 store personas | Equals the Executive total (no row lost or double-counted) |
| 6 | View as Regional with an email **not** in `UserAccess` | Blank / zero stores (default-deny) |
| 7 | Store persona, open the `Store` slicer and the store table | Only their store is listed (no leak via slicers) |
| 8 | Regional persona, `Region Share of Sales` | Shows 100% (the denominator is also secured) – expected, not a bug |
| 9 | Any role: select `UserAccess` fields in the field list | Only the user's own row |
| 10 | Publish, then **Security** in the service: map real users/groups to roles; test with *Test as role* | Same results as Desktop |

The `.csv` baseline is for the seed-42 dataset in `data/`; regenerate it if you regenerate the data.
