-- Run sql/kpi/vw_store_week_kpi.sql first (CREATE OR ALTER VIEW on SQL Server 2016 SP1+).
-- Company / region KPI summary for one week, re-derived from the view's components.
CREATE OR ALTER PROCEDURE dbo.usp_kpi_summary
    @week_start DATE,
    @region     NVARCHAR(20) = NULL      -- NULL = whole company
AS
BEGIN
    SET NOCOUNT ON;

    WITH wk AS (
        SELECT * FROM dbo.vw_store_week_kpi
        WHERE week_start = @week_start
          AND (@region IS NULL OR region = @region)
    )
    SELECT  @week_start AS week_start,
            COALESCE(@region, 'All regions') AS scope,
            SUM(net_sales)                                                     AS net_sales,
            (SUM(net_sales) - SUM(cogs)) * 1.0 / NULLIF(SUM(net_sales), 0)     AS gross_margin_pct,
            SUM(waste_cost) * 1.0 / NULLIF(SUM(cogs), 0)                       AS waste_pct_of_cogs,
            SUM(stockout_snapshots) * 1.0 / NULLIF(SUM(inventory_snapshots), 0) AS stockout_rate,
            SUM(po_lines_on_time) * 1.0 / NULLIF(SUM(po_lines_received), 0)    AS supplier_on_time_rate
    FROM wk;
END;
GO

-- Supplier scorecard for a date window (feeds the supplier page / ad-hoc checks).
CREATE OR ALTER PROCEDURE dbo.usp_supplier_scorecard
    @from_date_key INT,
    @to_date_key   INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT  su.supplier_name,
            COUNT(*)                                                          AS po_lines,
            SUM(CASE WHEN p.received_date_key <= p.promised_date_key THEN 1 ELSE 0 END) * 1.0
                / NULLIF(COUNT(*), 0)                                         AS on_time_rate,
            SUM(p.units_received) * 1.0 / NULLIF(SUM(p.units_ordered), 0)     AS fill_rate
    FROM dbo.fact_procurement p
    JOIN dbo.dim_supplier su ON su.supplier_key = p.supplier_key
    WHERE p.received_date_key BETWEEN @from_date_key AND @to_date_key
    GROUP BY su.supplier_name
    ORDER BY on_time_rate ASC;
END;
GO
