-- Store x week KPI layer. Plain ANSI SQL (CTEs + window functions), so the same
-- file runs on SQL Server, Snowflake and the SQLite demo target.
-- Components (sums/counts) are exposed next to the ratios so any roll-up
-- (region, company) can be re-derived correctly instead of averaging averages.
CREATE VIEW vw_store_week_kpi AS
WITH sales_w AS (
    SELECT d.week_start, f.store_key,
           SUM(f.units_sold) AS units_sold,
           SUM(f.net_sales)  AS net_sales,
           SUM(f.cogs)       AS cogs
    FROM fact_sales f
    JOIN dim_date d ON d.date_key = f.date_key
    GROUP BY d.week_start, f.store_key
),
inv_w AS (
    SELECT d.week_start, i.store_key,
           COUNT(*)            AS inventory_snapshots,
           SUM(i.is_stockout)  AS stockout_snapshots
    FROM fact_inventory i
    JOIN dim_date d ON d.date_key = i.date_key
    GROUP BY d.week_start, i.store_key
),
waste_w AS (
    SELECT d.week_start, w.store_key, SUM(w.waste_cost) AS waste_cost
    FROM fact_food_waste w
    JOIN dim_date d ON d.date_key = w.date_key
    GROUP BY d.week_start, w.store_key
),
po_w AS (
    -- on-time is judged in the week the goods actually arrived
    SELECT d.week_start, p.store_key,
           COUNT(*) AS po_lines_received,
           SUM(CASE WHEN p.received_date_key <= p.promised_date_key THEN 1 ELSE 0 END) AS po_lines_on_time,
           SUM(p.units_ordered)  AS units_ordered,
           SUM(p.units_received) AS units_received
    FROM fact_procurement p
    JOIN dim_date d ON d.date_key = p.received_date_key
    GROUP BY d.week_start, p.store_key
),
base AS (
    SELECT s.week_start, s.store_key,
           s.units_sold, s.net_sales, s.cogs,
           COALESCE(w.waste_cost, 0)           AS waste_cost,
           COALESCE(i.inventory_snapshots, 0)  AS inventory_snapshots,
           COALESCE(i.stockout_snapshots, 0)   AS stockout_snapshots,
           COALESCE(p.po_lines_received, 0)    AS po_lines_received,
           COALESCE(p.po_lines_on_time, 0)     AS po_lines_on_time,
           COALESCE(p.units_ordered, 0)        AS units_ordered,
           COALESCE(p.units_received, 0)       AS units_received
    FROM sales_w s
    LEFT JOIN inv_w   i ON i.week_start = s.week_start AND i.store_key = s.store_key
    LEFT JOIN waste_w w ON w.week_start = s.week_start AND w.store_key = s.store_key
    LEFT JOIN po_w    p ON p.week_start = s.week_start AND p.store_key = s.store_key
)
SELECT b.week_start, b.store_key, st.store_name, st.region,
       b.units_sold, b.net_sales, b.cogs, b.waste_cost,
       b.inventory_snapshots, b.stockout_snapshots,
       b.po_lines_received, b.po_lines_on_time, b.units_ordered, b.units_received,
       (b.net_sales - b.cogs) * 1.0 / NULLIF(b.net_sales, 0)           AS gross_margin_pct,
       b.waste_cost * 1.0 / NULLIF(b.cogs, 0)                          AS waste_pct_of_cogs,
       b.stockout_snapshots * 1.0 / NULLIF(b.inventory_snapshots, 0)   AS stockout_rate,
       b.po_lines_on_time * 1.0 / NULLIF(b.po_lines_received, 0)       AS supplier_on_time_rate,
       b.units_received * 1.0 / NULLIF(b.units_ordered, 0)             AS fill_rate,
       LAG(b.net_sales) OVER (PARTITION BY b.store_key ORDER BY b.week_start) AS net_sales_prev_week,
       b.net_sales * 1.0 / NULLIF(LAG(b.net_sales) OVER (PARTITION BY b.store_key ORDER BY b.week_start), 0) - 1
                                                                       AS net_sales_wow_pct
FROM base b
JOIN dim_store st ON st.store_key = b.store_key;
