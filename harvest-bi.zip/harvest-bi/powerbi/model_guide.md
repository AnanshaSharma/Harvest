# Power BI model guide

The repo ships the measures and security rules, not a `.pbix` (binary files can't be generated from code).
Build the model in ~20 minutes:

## 1. Load data
**Get Data > Text/CSV** for the nine files in `data/` (or connect to the `vw_store_week_kpi`-backed warehouse
on SQL Server / Snowflake). Use **Import** mode. Rename tables:

| File | Model table | Hide in report view |
|---|---|---|
| dim_date | `Date` | – |
| dim_store | `Store` | – |
| dim_product | `Product` | – |
| dim_supplier | `Supplier` | – |
| fact_sales | `Sales` | all key columns |
| fact_inventory | `Inventory` | all key columns |
| fact_procurement | `Procurement` | all key columns |
| fact_food_waste | `Waste` | all key columns |
| security_user_access | `UserAccess` | whole table |

Set types: `Date[full_date]` and `Date[week_start]` = Date; keys = Whole number.

## 2. Date table
Select `Date` > **Mark as date table** > `full_date`. Sort `Date[month_name]` by `Date[month]`.

## 3. Relationships (all many-to-one, single direction, fact -> dimension)
| From | To | Active |
|---|---|---|
| Sales[date_key], Inventory[date_key], Waste[date_key] | Date[date_key] | yes |
| Sales/Inventory/Waste/Procurement[store_key] | Store[store_key] | yes |
| Sales/Inventory/Waste/Procurement[product_key] | Product[product_key] | yes |
| Procurement[supplier_key] | Supplier[supplier_key] | yes |
| Procurement[received_date_key] | Date[date_key] | **yes** (on-time is attributed to the arrival week) |
| Procurement[order_date_key] | Date[date_key] | no (use `USERELATIONSHIP` if needed) |
| Procurement[promised_date_key] | Date[date_key] | no |

`UserAccess` has **no** relationships. `Product[supplier_key]` is descriptive only; don't relate it (it would
create a second path from Supplier to Product).

## 4. Measures
Paste `measures.dax` measure by measure into a `_Measures` table (Enter Data > empty table), grouped in display
folders: Sales, Time, Waste, Inventory, Procurement, Targets, Titles, Security. Format ratios as percentages.

## 5. Row-level security
See `docs/rls_guide.md`.

## 6. Suggested report pages (design for the Monday review, not the screenshot)
1. **Overview** – one-week slicer. Four KPI cards (Net Sales with WoW, Margin, Waste %, Stockout rate, Supplier OTD)
   whose colour comes from the `... Colour` measures; region bars sorted by sales; store ranking table with data bars.
2. **Supply** – supplier on-time % by supplier (sorted worst-first) + fill rate; trend of OTD by week.
3. **Waste & stock** – waste % of COGS by category; stockout rate by store; days of cover for flagged SKUs.

Design rules used: one colour = one meaning (red/amber/green only for status), sort so the problem is first,
KPI title is the sentence (`Headline Title`) not a label, tooltips carry the drill-down.
