# Harvest weekly KPI note - week of 2026-06-29

For the week starting 2026-06-29, net sales were 9,012,847 (-1.4% vs the prior week). Gross margin was 26.5% (prior week 26.5%). Food waste ran at 5.4% of cost of goods sold, and stockouts affected 11.7% of store-product days. Supplier on-time delivery was 83.8%, down from 84.8%. The weakest store was Harvest Ahmedabad (West) at -9.9% week over week.

_Source: template_
