"""Compute what every persona SHOULD see, straight from the warehouse.

Compare these numbers with Power BI Desktop > Modeling > View as (or with the
service's "Test as role") to prove row-level security by test, not assertion.

    python tools/rls_expected.py --db harvest.db --out docs/rls_expected_values.csv
"""
import argparse
import csv

from sqlalchemy import create_engine, text

SQL = """
SELECT u.email, u.role, u.region, u.store_key,
       COUNT(DISTINCT s.store_key)            AS stores_visible,
       ROUND(COALESCE(SUM(f.net_sales), 0), 2) AS net_sales_all_weeks,
       COALESCE(SUM(f.units_sold), 0)          AS units_sold_all_weeks
FROM security_user_access u
JOIN dim_store s
  ON  u.role = 'Executive'
   OR (u.role = 'Regional' AND s.region = u.region)
   OR (u.role = 'Store'    AND s.store_key = u.store_key)
LEFT JOIN fact_sales f ON f.store_key = s.store_key
GROUP BY u.email, u.role, u.region, u.store_key
ORDER BY CASE u.role WHEN 'Executive' THEN 1 WHEN 'Regional' THEN 2 ELSE 3 END, u.email
"""

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default="harvest.db")
    ap.add_argument("--out", default="docs/rls_expected_values.csv")
    a = ap.parse_args()
    with create_engine(f"sqlite:///{a.db}").connect() as c:
        rows = c.execute(text(SQL)).fetchall()
        cols = ["email", "role", "region", "store_key", "stores_visible", "net_sales_all_weeks", "units_sold_all_weeks"]
    with open(a.out, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(cols)
        w.writerows(rows)
    print(f"wrote {len(rows)} personas to {a.out}")
