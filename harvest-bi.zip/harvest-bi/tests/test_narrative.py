from harvest import etl, kpi, narrative


def _summary(loaded):
    etl.merge_to_warehouse(loaded, "sqlite")
    etl.create_views(loaded)
    return kpi.build_summary(loaded)


def test_template_narrative_uses_only_summary_figures(loaded):
    s = _summary(loaded)
    text, source = narrative.template_narrative(s), "template"
    assert f"{s['current']['net_sales']:,.0f}" in text
    assert f"{s['current']['gross_margin_pct'] * 100:.1f}%" in text
    assert source == "template"


def test_falls_back_to_template_when_claude_fails(loaded, monkeypatch):
    s = _summary(loaded)
    monkeypatch.setenv("ANTHROPIC_API_KEY", "dummy")
    monkeypatch.setattr(narrative, "claude_narrative", lambda *_a, **_k: (_ for _ in ()).throw(RuntimeError("boom")))
    text, source = narrative.generate_narrative(s)
    assert source == "template" and text


def test_no_api_key_uses_template(loaded, monkeypatch):
    s = _summary(loaded)
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    assert narrative.generate_narrative(s)[1] == "template"
