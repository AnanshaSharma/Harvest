import pandas as pd
from sqlalchemy import text

from harvest import etl, validate
from harvest.generate_data import generate


def test_clean_load_passes_all_checks(loaded):
    assert not validate.failed_errors(validate.validate_staging(loaded))
    etl.merge_to_warehouse(loaded, "sqlite")
    assert not validate.failed_errors(validate.validate_warehouse(loaded))


def test_duplicate_grain_in_staging_is_caught(loaded):
    with loaded.begin() as c:
        c.execute(text("INSERT INTO stg_fact_sales SELECT * FROM stg_fact_sales LIMIT 1"))
    failed = validate.failed_errors(validate.validate_staging(loaded))
    assert [r.name for r in failed] == ["duplicate grain: stg_fact_sales"]


def test_orphan_key_is_caught(loaded):
    etl.merge_to_warehouse(loaded, "sqlite")
    with loaded.begin() as c:
        c.execute(text("UPDATE fact_sales SET store_key = 999 WHERE rowid = (SELECT MIN(rowid) FROM fact_sales)"))
    failed = [r.name for r in validate.failed_errors(validate.validate_warehouse(loaded))]
    assert "orphan keys: fact_sales.store_key -> dim_store" in failed


def test_merge_is_idempotent(loaded):
    etl.merge_to_warehouse(loaded, "sqlite")
    first = etl.row_counts(loaded)
    etl.merge_to_warehouse(loaded, "sqlite")
    assert etl.row_counts(loaded) == first


def test_merge_updates_changed_rows_without_duplicating(loaded, frames):
    etl.merge_to_warehouse(loaded, "sqlite")
    changed = {k: v.copy() for k, v in frames.items()}
    changed["dim_store"].loc[0, "region"] = "Central"
    etl.load_staging(loaded, changed)
    etl.merge_to_warehouse(loaded, "sqlite")
    with loaded.connect() as c:
        assert c.execute(text("SELECT region FROM dim_store WHERE store_key = 1")).scalar() == "Central"
        assert c.execute(text("SELECT COUNT(*) FROM dim_store")).scalar() == len(frames["dim_store"])


def test_kpi_view_ratios_match_components(loaded):
    etl.merge_to_warehouse(loaded, "sqlite")
    etl.create_views(loaded)
    df = pd.read_sql("SELECT * FROM vw_store_week_kpi", loaded)
    assert not df.empty
    expect = (df["net_sales"] - df["cogs"]) / df["net_sales"]
    assert (df["gross_margin_pct"] - expect).abs().max() < 1e-9
    first_week = df["week_start"].min()
    assert df.loc[df["week_start"] == first_week, "net_sales_prev_week"].isna().all()
