import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from harvest import etl  # noqa: E402
from harvest.db import get_engine  # noqa: E402
from harvest.generate_data import generate  # noqa: E402


@pytest.fixture(scope="session")
def frames():
    return generate(seed=7, weeks=4)


@pytest.fixture()
def loaded(tmp_path, frames):
    """A fresh SQLite warehouse with staging loaded but NOT yet merged."""
    engine = get_engine("sqlite", str(tmp_path / "t.db"))
    etl.create_schema(engine, "sqlite")
    etl.load_staging(engine, frames)
    return engine
