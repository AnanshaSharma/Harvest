from harvest.generate_data import generate
from harvest.schema import TABLES


def test_deterministic_for_same_seed():
    a, b = generate(seed=3, weeks=2), generate(seed=3, weeks=2)
    assert a["fact_sales"].equals(b["fact_sales"])
    assert a["fact_procurement"].equals(b["fact_procurement"])


def test_grain_is_unique_in_every_table(frames):
    for t in TABLES:
        assert not frames[t["name"]].duplicated(subset=t["key"]).any(), t["name"]


def test_facts_are_internally_consistent(frames):
    inv = frames["fact_inventory"]
    assert (inv["units_on_hand"] >= 0).all()
    assert ((inv["is_stockout"] == 1) == (inv["units_on_hand"] == 0)).all()
    po = frames["fact_procurement"]
    assert (po["received_date_key"] >= po["promised_date_key"]).all()
    assert (po["units_received"] <= po["units_ordered"]).all()
