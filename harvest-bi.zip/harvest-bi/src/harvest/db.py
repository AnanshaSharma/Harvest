"""Engine factory for the three supported targets.

sqlite     - zero-setup demo (default); runs the full pipeline locally.
sqlserver  - needs `pip install pyodbc` + ODBC Driver 18; set MSSQL_* env vars.
snowflake  - needs `pip install snowflake-sqlalchemy`; set SNOWFLAKE_* env vars.
"""
import os
from urllib.parse import quote_plus

from sqlalchemy import create_engine


def get_engine(target="sqlite", sqlite_path="harvest.db"):
    if target == "sqlite":
        return create_engine(f"sqlite:///{sqlite_path}")
    if target == "sqlserver":
        odbc = (
            f"DRIVER={{ODBC Driver 18 for SQL Server}};SERVER={os.environ['MSSQL_SERVER']};"
            f"DATABASE={os.environ.get('MSSQL_DATABASE', 'harvest')};UID={os.environ['MSSQL_USER']};"
            f"PWD={os.environ['MSSQL_PASSWORD']};TrustServerCertificate=yes"
        )
        return create_engine(f"mssql+pyodbc:///?odbc_connect={quote_plus(odbc)}", fast_executemany=True)
    if target == "snowflake":
        from snowflake.sqlalchemy import URL
        return create_engine(URL(
            account=os.environ["SNOWFLAKE_ACCOUNT"], user=os.environ["SNOWFLAKE_USER"],
            password=os.environ["SNOWFLAKE_PASSWORD"], warehouse=os.environ["SNOWFLAKE_WAREHOUSE"],
            database=os.environ.get("SNOWFLAKE_DATABASE", "HARVEST"),
            schema=os.environ.get("SNOWFLAKE_SCHEMA", "PUBLIC")))
    raise ValueError(f"Unknown target: {target}")
