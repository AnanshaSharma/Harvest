"""Staging load + idempotent MERGE upsert.

Flow per run:  truncate staging -> bulk load staging -> validate staging ->
MERGE into warehouse (single transaction) -> validate warehouse.
Re-running with the same input leaves the warehouse unchanged.
"""
import re
from pathlib import Path

import pandas as pd
from sqlalchemy import text

from .schema import TABLES, non_key_cols

ROOT = Path(__file__).resolve().parents[2]


def _run_script(conn, path):
    """Execute a simple ';'-separated script (no procedure bodies)."""
    for stmt in Path(path).read_text().split(";"):
        lines = [ln for ln in stmt.splitlines() if not ln.strip().startswith("--")]
        sql = "\n".join(lines).strip()
        if sql:
            conn.execute(text(sql))


def create_schema(engine, target):
    """SQLite creates itself (warehouse tables are kept between runs, staging is
    recreated). For SQL Server / Snowflake run the generated scripts in
    sql/<target>/ once (SSMS, sqlcmd or SnowSQL) - see README."""
    if target != "sqlite":
        return
    ddl = (ROOT / "sql/sqlite/01_schema.sql").read_text()
    with engine.begin() as conn:
        existing = {r[0] for r in conn.execute(text("SELECT name FROM sqlite_master WHERE type='table'"))}
        for stmt in ddl.split(";"):
            m = re.search(r"CREATE TABLE (\w+)", stmt)
            if not m:
                continue
            name = m.group(1)
            if name.startswith("stg_"):
                conn.execute(text(f"DROP TABLE IF EXISTS {name}"))
            elif name in existing:
                continue
            conn.execute(text(stmt.strip()))


def load_staging(engine, frames):
    with engine.begin() as conn:
        for t in TABLES:
            conn.execute(text(f"DELETE FROM stg_{t['name']}"))
    for t in TABLES:
        df = frames[t["name"]]
        cols = [c for c, _ in t["cols"]]
        df[cols].to_sql(f"stg_{t['name']}", engine, if_exists="append", index=False,
                        chunksize=5000, method="multi" if engine.dialect.name != "sqlite" else None)


def merge_to_warehouse(engine, target):
    with engine.begin() as conn:
        if target == "sqlserver":
            conn.execute(text("EXEC dbo.usp_merge_all"))
        elif target == "snowflake":
            _run_script(conn, ROOT / "sql/snowflake/02_merge.sql")
        else:  # sqlite: same upsert semantics via INSERT .. ON CONFLICT DO UPDATE
            for t in TABLES:
                cols = [c for c, _ in t["cols"]]
                nk = non_key_cols(t)
                sql = (f"INSERT INTO {t['name']} ({', '.join(cols)}) "
                       f"SELECT {', '.join(cols)} FROM stg_{t['name']} WHERE true "
                       f"ON CONFLICT ({', '.join(t['key'])}) ")
                sql += ("DO UPDATE SET " + ", ".join(f"{c} = excluded.{c}" for c in nk)
                        + " WHERE " + " OR ".join(f"{t['name']}.{c} IS NOT excluded.{c}" for c in nk)) if nk else "DO NOTHING"
                conn.execute(text(sql))


def create_views(engine):
    sql = (ROOT / "sql/kpi/vw_store_week_kpi.sql").read_text()
    with engine.begin() as conn:
        conn.execute(text("DROP VIEW IF EXISTS vw_store_week_kpi"))
        conn.execute(text(sql.rstrip().rstrip(";")))


def row_counts(engine):
    with engine.connect() as conn:
        return {t["name"]: conn.execute(text(f"SELECT COUNT(*) FROM {t['name']}")).scalar() for t in TABLES}
