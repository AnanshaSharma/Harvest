"""Headline KPI summary for the latest week, read from vw_store_week_kpi.

Company and region ratios are re-derived from summed components (never an
average of store ratios), which is the same rule the DAX measures follow.
"""
import pandas as pd


def _rollup(df):
    s = df.sum(numeric_only=True)
    div = lambda a, b: float(a) / float(b) if b else None  # noqa: E731
    return {
        "net_sales": float(s["net_sales"]),
        "gross_margin_pct": div(s["net_sales"] - s["cogs"], s["net_sales"]),
        "waste_pct_of_cogs": div(s["waste_cost"], s["cogs"]),
        "stockout_rate": div(s["stockout_snapshots"], s["inventory_snapshots"]),
        "supplier_on_time_rate": div(s["po_lines_on_time"], s["po_lines_received"]),
    }


def _delta(cur, prev):
    return None if prev in (None, 0) or cur is None else cur / prev - 1


def build_summary(engine):
    df = pd.read_sql("SELECT * FROM vw_store_week_kpi", engine)
    weeks = sorted(df["week_start"].unique())
    last, prev = weeks[-1], (weeks[-2] if len(weeks) > 1 else None)
    cur_df = df[df["week_start"] == last]
    prev_df = df[df["week_start"] == prev] if prev else cur_df.iloc[0:0]

    cur = _rollup(cur_df)
    prv = _rollup(prev_df) if prev else {k: None for k in cur}
    summary = {
        "week_start": last, "prev_week_start": prev, "current": cur, "previous": prv,
        "net_sales_wow_pct": _delta(cur["net_sales"], prv["net_sales"]),
    }

    regions = []
    for region, g in cur_df.groupby("region"):
        r = _rollup(g)
        r["region"] = region
        regions.append(r)
    summary["regions"] = sorted(regions, key=lambda r: r["net_sales"], reverse=True)

    movers = cur_df.dropna(subset=["net_sales_wow_pct"]).sort_values("net_sales_wow_pct")
    pick = lambda row: {"store": row["store_name"], "region": row["region"],  # noqa: E731
                        "net_sales_wow_pct": float(row["net_sales_wow_pct"])}
    summary["worst_store"] = pick(movers.iloc[0]) if len(movers) else None
    summary["best_store"] = pick(movers.iloc[-1]) if len(movers) else None
    return summary
