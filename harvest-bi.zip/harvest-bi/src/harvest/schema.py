"""Single source of truth for the Harvest warehouse model.

Everything else (DDL, MERGE statements, loaders, validation) is derived from
this spec so the SQL Server, Snowflake and SQLite scripts can never drift apart.
Generic types: int, flag, dec, text(n), date.
"""

TABLES = [
    # ---------------- dimensions ----------------
    dict(name="dim_date", kind="dim", key=["date_key"], cols=[
        ("date_key", "int"), ("full_date", "date"), ("year", "int"), ("quarter", "int"),
        ("month", "int"), ("month_name", "text(12)"), ("week_start", "date"),
        ("day_of_week", "int"), ("is_weekend", "flag")]),
    dict(name="dim_store", kind="dim", key=["store_key"], cols=[
        ("store_key", "int"), ("store_name", "text(60)"), ("region", "text(20)"),
        ("city", "text(40)"), ("format", "text(20)"), ("open_date", "date")]),
    dict(name="dim_product", kind="dim", key=["product_key"], cols=[
        ("product_key", "int"), ("sku", "text(20)"), ("product_name", "text(60)"),
        ("category", "text(30)"), ("unit_cost", "dec"), ("unit_price", "dec"),
        ("shelf_life_days", "int"), ("supplier_key", "int")]),
    dict(name="dim_supplier", kind="dim", key=["supplier_key"], cols=[
        ("supplier_key", "int"), ("supplier_name", "text(60)"), ("lead_time_days", "int")]),
    dict(name="security_user_access", kind="dim", key=["email"], cols=[
        ("email", "text(80)"), ("role", "text(20)"), ("region", "text(20)"), ("store_key", "int")]),
    # ---------------- facts ----------------
    dict(name="fact_sales", kind="fact", key=["date_key", "store_key", "product_key"], cols=[
        ("date_key", "int"), ("store_key", "int"), ("product_key", "int"),
        ("units_sold", "int"), ("net_sales", "dec"), ("cogs", "dec")]),
    dict(name="fact_inventory", kind="fact", key=["date_key", "store_key", "product_key"], cols=[
        ("date_key", "int"), ("store_key", "int"), ("product_key", "int"),
        ("units_on_hand", "int"), ("is_stockout", "flag")]),
    dict(name="fact_procurement", kind="fact", key=["po_line_id"], cols=[
        ("po_line_id", "int"), ("order_date_key", "int"), ("promised_date_key", "int"),
        ("received_date_key", "int"), ("store_key", "int"), ("product_key", "int"),
        ("supplier_key", "int"), ("units_ordered", "int"), ("units_received", "int"),
        ("unit_cost", "dec")]),
    dict(name="fact_food_waste", kind="fact", key=["date_key", "store_key", "product_key"], cols=[
        ("date_key", "int"), ("store_key", "int"), ("product_key", "int"),
        ("units_wasted", "int"), ("waste_cost", "dec"), ("reason", "text(20)")]),
]

BY_NAME = {t["name"]: t for t in TABLES}


def non_key_cols(t):
    return [c for c, _ in t["cols"] if c not in t["key"]]
