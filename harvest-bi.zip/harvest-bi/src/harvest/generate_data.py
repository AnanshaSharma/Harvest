"""Synthetic data for a 12-store retail / food-service chain.

Deterministic for a given seed. Inventory, sales, waste and purchase orders are
simulated together per store x product so the facts reconcile with each other
(you cannot sell stock you never received). One supplier degrades in the last
three weeks so the KPI layer has a real story to surface.
"""
from datetime import date, timedelta
from pathlib import Path

import numpy as np
import pandas as pd

REGIONS = {
    "North": ["Delhi", "Gurugram", "Chandigarh", "Jaipur"],
    "South": ["Bengaluru", "Chennai", "Hyderabad", "Kochi"],
    "West": ["Mumbai", "Pune", "Ahmedabad", "Surat"],
}
CATEGORIES = {
    "Bakery": (3, ["Sourdough Loaf", "Croissant", "Bagel", "Muffin", "Baguette"]),
    "Dairy": (7, ["Whole Milk 1L", "Greek Yogurt", "Cheddar Block", "Butter", "Paneer"]),
    "Produce": (5, ["Tomatoes", "Spinach", "Bananas", "Avocados", "Bell Peppers"]),
    "Meat & Fish": (4, ["Chicken Breast", "Minced Mutton", "Salmon Fillet", "Prawns", "Chicken Sausages"]),
    "Beverages": (180, ["Cold Brew", "Orange Juice", "Sparkling Water", "Iced Tea", "Energy Drink"]),
    "Snacks": (120, ["Trail Mix", "Potato Chips", "Granola Bar", "Popcorn", "Dark Chocolate"]),
    "Frozen": (90, ["Frozen Pizza", "Ice Cream", "Frozen Peas", "French Fries", "Dumplings"]),
    "Pantry": (365, ["Basmati Rice", "Olive Oil", "Pasta", "Coffee Beans", "Peanut Butter"]),
}
WEEKDAY_FACTOR = [0.85, 0.85, 0.9, 0.95, 1.2, 1.35, 1.1]  # Mon..Sun
DEGRADED_SUPPLIER = 3


def _dim_date(dates):
    rows = []
    for d in dates:
        rows.append(dict(
            date_key=int(d.strftime("%Y%m%d")), full_date=d.isoformat(), year=d.year,
            quarter=(d.month - 1) // 3 + 1, month=d.month, month_name=d.strftime("%B"),
            week_start=(d - timedelta(days=d.weekday())).isoformat(),
            day_of_week=d.weekday() + 1, is_weekend=int(d.weekday() >= 5)))
    return pd.DataFrame(rows)


def generate(seed=42, start="2026-01-05", weeks=26):
    rng = np.random.default_rng(seed)
    start_d = date.fromisoformat(start)
    n_days = weeks * 7
    dates = [start_d + timedelta(days=i) for i in range(n_days)]
    dkey = [int(d.strftime("%Y%m%d")) for d in dates]

    suppliers = []
    for i in range(1, 9):
        suppliers.append(dict(supplier_key=i, supplier_name=f"Supplier {chr(64 + i)} Foods",
                              lead_time_days=int(rng.integers(2, 7)),
                              on_time_prob=float(rng.uniform(0.80, 0.97))))
    stores, sk = [], 1
    for region, cities in REGIONS.items():
        for city in cities:
            stores.append(dict(store_key=sk, store_name=f"Harvest {city}", region=region, city=city,
                               format=str(rng.choice(["Express", "Standard", "Flagship"], p=[0.3, 0.5, 0.2])),
                               open_date=(date(2019, 1, 1) + timedelta(days=int(rng.integers(0, 1500)))).isoformat(),
                               size=float(rng.uniform(0.7, 1.4))))
            sk += 1
    products, pk = [], 1
    for cat, (shelf, names) in CATEGORIES.items():
        for nm in names:
            cost = round(float(rng.uniform(20, 400)), 2)
            products.append(dict(product_key=pk, sku=f"SKU-{pk:04d}", product_name=nm, category=cat,
                                 unit_cost=cost, unit_price=round(cost * float(rng.uniform(1.25, 1.6)), 2),
                                 shelf_life_days=shelf, supplier_key=(pk - 1) % 8 + 1,
                                 popularity=float(rng.uniform(3, 14))))
            pk += 1

    sales, inv, waste, po = [], [], [], []
    po_id = 1
    for s in stores:
        for p in products:
            sup = suppliers[p["supplier_key"] - 1]
            base = p["popularity"] * s["size"]
            on_hand = int(base * 8)
            pending = {}
            offset = int(rng.integers(0, 7))
            for i, d in enumerate(dates):
                on_hand += pending.pop(i, 0)
                if i % 7 == offset:
                    qty = int(round(base * 8))
                    lead = sup["lead_time_days"]
                    prob = 0.4 if (sup["supplier_key"] == DEGRADED_SUPPLIER and i >= n_days - 21) else sup["on_time_prob"]
                    delay = 0 if rng.random() < prob else int(rng.integers(1, 5))
                    promised_i, recv_i = i + lead, i + lead + delay
                    if recv_i < n_days:
                        recv_units = qty if rng.random() > 0.08 else int(qty * rng.uniform(0.7, 0.95))
                        pending[recv_i] = pending.get(recv_i, 0) + recv_units
                        po.append(dict(po_line_id=po_id, order_date_key=dkey[i], promised_date_key=dkey[promised_i],
                                       received_date_key=dkey[recv_i], store_key=s["store_key"],
                                       product_key=p["product_key"], supplier_key=sup["supplier_key"],
                                       units_ordered=qty, units_received=recv_units, unit_cost=p["unit_cost"]))
                        po_id += 1
                demand = int(rng.poisson(base * WEEKDAY_FACTOR[d.weekday()] * (1 + 0.0008 * i)))
                sold = min(demand, on_hand)
                on_hand -= sold
                if sold > 0:
                    disc = float(rng.choice([0, 0, 0, 0.05, 0.1]))
                    sales.append((dkey[i], s["store_key"], p["product_key"], sold,
                                  round(sold * p["unit_price"] * (1 - disc), 2), round(sold * p["unit_cost"], 2)))
                wasted, reason = 0, "expired"
                if p["shelf_life_days"] <= 7 and on_hand > 0:
                    wasted = int(rng.binomial(on_hand, 0.05 if p["shelf_life_days"] <= 4 else 0.025))
                elif p["shelf_life_days"] >= 90 and on_hand > 3 and rng.random() < 0.002:
                    wasted, reason = int(rng.integers(1, 4)), "damaged"
                if wasted > 0:
                    on_hand -= wasted
                    waste.append((dkey[i], s["store_key"], p["product_key"], wasted,
                                  round(wasted * p["unit_cost"], 2), reason))
                inv.append((dkey[i], s["store_key"], p["product_key"], on_hand, int(on_hand == 0)))

    access = [dict(email="exec@harvest.example", role="Executive", region=None, store_key=None)]
    for region in REGIONS:
        access.append(dict(email=f"{region.lower()}.manager@harvest.example", role="Regional", region=region, store_key=None))
    for s in stores:
        access.append(dict(email=f"store{s['store_key']}@harvest.example", role="Store", region=s["region"], store_key=s["store_key"]))

    return {
        "dim_date": _dim_date(dates),
        "dim_store": pd.DataFrame(stores).drop(columns="size"),
        "dim_product": pd.DataFrame(products).drop(columns="popularity"),
        "dim_supplier": pd.DataFrame(suppliers).drop(columns="on_time_prob"),
        "security_user_access": pd.DataFrame(access),
        "fact_sales": pd.DataFrame(sales, columns=["date_key", "store_key", "product_key", "units_sold", "net_sales", "cogs"]),
        "fact_inventory": pd.DataFrame(inv, columns=["date_key", "store_key", "product_key", "units_on_hand", "is_stockout"]),
        "fact_procurement": pd.DataFrame(po),
        "fact_food_waste": pd.DataFrame(waste, columns=["date_key", "store_key", "product_key", "units_wasted", "waste_cost", "reason"]),
    }


def write_csvs(frames, out_dir):
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    for name, df in frames.items():
        df.to_csv(out / f"{name}.csv", index=False)
