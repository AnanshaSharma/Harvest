"""Data validation and reconciliation checks.

Two phases:
  validate_staging   - before MERGE: duplicate grain would make MERGE fail or
                       silently pick a row, so it is a hard stop.
  validate_warehouse - after MERGE: staging-vs-warehouse totals, orphan keys,
                       business-rule violations.
Every check returns a CheckResult; the pipeline stops on any failed 'error'.
"""
from dataclasses import dataclass

from sqlalchemy import text

from .schema import BY_NAME, TABLES

FACT_DIM_LINKS = {
    "fact_sales": [("date_key", "dim_date"), ("store_key", "dim_store"), ("product_key", "dim_product")],
    "fact_inventory": [("date_key", "dim_date"), ("store_key", "dim_store"), ("product_key", "dim_product")],
    "fact_food_waste": [("date_key", "dim_date"), ("store_key", "dim_store"), ("product_key", "dim_product")],
    "fact_procurement": [("order_date_key", "dim_date"), ("promised_date_key", "dim_date"),
                         ("received_date_key", "dim_date"), ("store_key", "dim_store"),
                         ("product_key", "dim_product"), ("supplier_key", "dim_supplier")],
}
DIM_KEY = {t["name"]: t["key"][0] for t in TABLES if t["kind"] == "dim"}
MEASURE_TOTALS = {"fact_sales": ["net_sales", "cogs", "units_sold"],
                  "fact_food_waste": ["waste_cost", "units_wasted"],
                  "fact_procurement": ["units_ordered", "units_received"]}


@dataclass
class CheckResult:
    name: str
    passed: bool
    detail: str
    severity: str = "error"


def _scalar(conn, sql):
    return conn.execute(text(sql)).scalar()


def validate_staging(engine):
    results = []
    with engine.connect() as conn:
        for t in TABLES:
            key = ", ".join(t["key"])
            n = _scalar(conn, f"SELECT COUNT(*) FROM (SELECT {key} FROM stg_{t['name']} "
                              f"GROUP BY {key} HAVING COUNT(*) > 1) d")
            results.append(CheckResult(f"duplicate grain: stg_{t['name']}", n == 0,
                                       f"{n} duplicated key(s) on ({key})"))
    return results


def validate_warehouse(engine):
    results = []
    with engine.connect() as conn:
        # 1. staging vs warehouse totals for the keys that were just loaded
        for fact, measures in MEASURE_TOTALS.items():
            join = " AND ".join(f"f.{k} = s.{k}" for k in BY_NAME[fact]["key"])
            for m in measures:
                stg = _scalar(conn, f"SELECT COALESCE(SUM({m}), 0) FROM stg_{fact}")
                wh = _scalar(conn, f"SELECT COALESCE(SUM(f.{m}), 0) FROM {fact} f "
                                   f"JOIN stg_{fact} s ON {join}")
                results.append(CheckResult(f"reconcile {fact}.{m}", abs(float(stg) - float(wh)) < 0.01,
                                           f"staging={float(stg):,.2f} warehouse={float(wh):,.2f}"))
        # 2. orphan keys
        for fact, links in FACT_DIM_LINKS.items():
            for col, dim in links:
                dk = DIM_KEY[dim]
                n = _scalar(conn, f"SELECT COUNT(*) FROM {fact} f LEFT JOIN {dim} d ON d.{dk} = f.{col} "
                                  f"WHERE d.{dk} IS NULL")
                results.append(CheckResult(f"orphan keys: {fact}.{col} -> {dim}", n == 0, f"{n} orphan row(s)"))
        # 3. business rules
        rules = {
            "no negative sales / cost": "SELECT COUNT(*) FROM fact_sales WHERE net_sales < 0 OR cogs < 0 OR units_sold <= 0",
            "no negative inventory": "SELECT COUNT(*) FROM fact_inventory WHERE units_on_hand < 0",
            "stockout flag is 0/1 and matches on-hand": "SELECT COUNT(*) FROM fact_inventory WHERE is_stockout NOT IN (0, 1) "
                                                         "OR (is_stockout = 1 AND units_on_hand <> 0)",
            "PO received on/after order date": "SELECT COUNT(*) FROM fact_procurement WHERE received_date_key < order_date_key",
            "PO received units <= ordered units": "SELECT COUNT(*) FROM fact_procurement WHERE units_received > units_ordered",
            "waste cost non-negative": "SELECT COUNT(*) FROM fact_food_waste WHERE waste_cost < 0 OR units_wasted <= 0",
        }
        for name, sql in rules.items():
            n = _scalar(conn, sql)
            results.append(CheckResult(f"rule: {name}", n == 0, f"{n} violating row(s)"))
    return results


def failed_errors(results):
    return [r for r in results if not r.passed and r.severity == "error"]


def format_results(results):
    return "\n".join(f"[{'PASS' if r.passed else 'FAIL'}] {r.name} - {r.detail}" for r in results)
