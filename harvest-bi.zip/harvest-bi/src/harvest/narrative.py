"""Plain-English weekly narrative for the KPI summary.

Primary path: Claude API (set ANTHROPIC_API_KEY). The model is told to use ONLY
the figures supplied, so it narrates the governed numbers rather than inventing
its own. Any failure (no key, network, API error, empty reply) falls back to a
deterministic template, so the pipeline always produces a report.
"""
import json
import os

SYSTEM_PROMPT = (
    "You are a retail operations analyst writing the Monday KPI note for a store-chain leadership team. "
    "Use ONLY the figures in the JSON provided; never invent numbers, causes or comparisons. "
    "Write 4-6 sentences of plain English: lead with net sales and its week-over-week change, "
    "then margin, waste, stockouts and supplier on-time delivery, and end with the single metric "
    "that most needs attention. Percentages with one decimal place."
)


def _pct(x, signed=False):
    if x is None:
        return "n/a"
    return f"{x * 100:+.1f}%" if signed else f"{x * 100:.1f}%"


def template_narrative(s):
    c, p = s["current"], s["previous"]
    parts = [
        f"For the week starting {s['week_start']}, net sales were {c['net_sales']:,.0f}"
        + (f" ({_pct(s['net_sales_wow_pct'], True)} vs the prior week)." if s["net_sales_wow_pct"] is not None else "."),
        f"Gross margin was {_pct(c['gross_margin_pct'])}"
        + (f" (prior week {_pct(p['gross_margin_pct'])})." if p["gross_margin_pct"] is not None else "."),
        f"Food waste ran at {_pct(c['waste_pct_of_cogs'])} of cost of goods sold, and stockouts affected "
        f"{_pct(c['stockout_rate'])} of store-product days.",
        f"Supplier on-time delivery was {_pct(c['supplier_on_time_rate'])}"
        + (f", down from {_pct(p['supplier_on_time_rate'])}." if p["supplier_on_time_rate"] is not None
           and c["supplier_on_time_rate"] is not None and c["supplier_on_time_rate"] < p["supplier_on_time_rate"] - 0.005
           else "."),
    ]
    if s.get("worst_store"):
        w = s["worst_store"]
        parts.append(f"The weakest store was {w['store']} ({w['region']}) at {_pct(w['net_sales_wow_pct'], True)} week over week.")
    # single "needs attention" call-out: largest adverse move among delivery / stockouts
    if p["supplier_on_time_rate"] is not None and c["supplier_on_time_rate"] is not None:
        drop = p["supplier_on_time_rate"] - c["supplier_on_time_rate"]
        if drop > 0.03:
            parts.append(f"Needs attention: supplier on-time delivery fell {drop * 100:.1f} points.")
    return " ".join(parts)


def claude_narrative(s, model=None):
    import anthropic  # imported lazily so the package works without it

    client = anthropic.Anthropic()
    msg = client.messages.create(
        model=model or os.environ.get("HARVEST_CLAUDE_MODEL", "claude-sonnet-5-5"),
        max_tokens=400,
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": json.dumps(s, default=str)}],
    )
    return "".join(b.text for b in msg.content if getattr(b, "type", "") == "text").strip()


def generate_narrative(summary):
    """Returns (text, source) where source is 'claude' or 'template'."""
    if os.environ.get("ANTHROPIC_API_KEY"):
        try:
            out = claude_narrative(summary)
            if out:
                return out, "claude"
        except Exception as exc:  # noqa: BLE001 - deliberate catch-all, we always fall back
            print(f"[narrative] Claude API unavailable ({type(exc).__name__}); using template fallback.")
    return template_narrative(summary), "template"
