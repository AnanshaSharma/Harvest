"""End-to-end pipeline.

    python -m harvest.run_pipeline --target sqlite --generate
"""
import argparse
import sys
from pathlib import Path

from . import etl, kpi, narrative, validate
from .db import get_engine
from .generate_data import generate, write_csvs

ROOT = Path(__file__).resolve().parents[2]


def load_frames_from_csv(data_dir):
    import pandas as pd
    from .schema import TABLES
    return {t["name"]: pd.read_csv(Path(data_dir) / f"{t['name']}.csv") for t in TABLES}


def main(argv=None):
    ap = argparse.ArgumentParser(description="Harvest BI pipeline")
    ap.add_argument("--target", default="sqlite", choices=["sqlite", "sqlserver", "snowflake"])
    ap.add_argument("--db", default=str(ROOT / "harvest.db"), help="SQLite file (sqlite target only)")
    ap.add_argument("--data-dir", default=str(ROOT / "data"))
    ap.add_argument("--generate", action="store_true", help="(re)generate synthetic CSVs first")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--report", default=str(ROOT / "reports" / "weekly_narrative.md"))
    args = ap.parse_args(argv)

    if args.generate or not (Path(args.data_dir) / "fact_sales.csv").exists():
        print("1/6 Generating synthetic data ...")
        write_csvs(generate(seed=args.seed), args.data_dir)
    frames = load_frames_from_csv(args.data_dir)

    engine = get_engine(args.target, args.db)
    etl.create_schema(engine, args.target)

    print("2/6 Loading staging ...")
    etl.load_staging(engine, frames)

    print("3/6 Validating staging (duplicate grain) ...")
    res = validate.validate_staging(engine)
    print(validate.format_results(res))
    if validate.failed_errors(res):
        sys.exit("Staging validation failed - MERGE not run.")

    print("4/6 MERGE into warehouse ...")
    etl.merge_to_warehouse(engine, args.target)
    res = validate.validate_warehouse(engine)
    print(validate.format_results(res))
    if validate.failed_errors(res):
        sys.exit("Warehouse reconciliation failed - investigate before publishing.")

    print("5/6 Building KPI view ...")
    etl.create_views(engine)
    summary = kpi.build_summary(engine)

    print("6/6 Generating weekly narrative ...")
    text, source = narrative.generate_narrative(summary)
    Path(args.report).parent.mkdir(parents=True, exist_ok=True)
    Path(args.report).write_text(
        f"# Harvest weekly KPI note - week of {summary['week_start']}\n\n{text}\n\n_Source: {source}_\n")
    print(f"\nNarrative ({source}):\n{text}\n\nRow counts: {etl.row_counts(engine)}")


if __name__ == "__main__":
    main()
